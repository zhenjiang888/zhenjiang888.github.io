
1. The Injective Language Inv
=============================


In many occasions would one encounter the task of maintaining 
the consistency of two pieces of structured data that are related 
by some transform --- synchronising bookmarks in different web 
browsers, the source and the view in an editor, or views in 
databases, to name a few.

In our prototype XML editor, XEditor, a source XML document is 
transformed to a user-friendly, editable view through a transform 
defined by the document designer. The editing performed by the user 
on the view needs to be reflected back to the source document. 
Similar  techniques can also be used to synchronise several bookmarks 
stored in formats of different browsers, to maintain invariance 
among widgets in an user interface, or to maintain the consistency 
of data and view in databases.

Our approach to the above bidirectional updating problem is rather 
different from the previous ones. We extend the injective functional 
language Inv, designed in [1], in which only injective functions are 
definable and therefore every program is trivially invertible. The 
document designer specifies the transform as if she were defining 
an injective function from the source to the view. A special operator 
for duplication specifies all element-wise dependency.

To deal with inconsistencies resulting from editing, however, we 
define an alternative semantics, under which the behaviour of programs 
can be reasoned by algebraic rules. It is a good application of program 
inversion and algebraic reasoning, and the result will soon be integrated 
into XEditor.

1.1 An Inv Tutorial
------------

We have a prototype implementation of the language Inv written 
in Haskell. To load the interpreter using either hugs or
ghci:

   hugs -98 X.lhs
   ghci X.lhs

The Interpreter is invoked with the function ev:

 X> :i ev
 ev :: Inv Val -> [Char] -> Either (Err (Inv Val) Val) Val

It takes an Inv expression, a string representing a Val value 
(which will be parsed by a parser), and returns either the result 
or an error message. Let's try the function unziplist, which is 
defined in the Inv Prelude as:

   unziplist = Define "unzip" (Inv ziplist)
   ziplist = Define "zip"
              (Fix (\x -> (Inv Nil :*: Inv Nil) <.> eq <.> Nil <|>
                          (Inv Cons :**: Inv Cons) <.> trans <.>
                             (Id :*: x) <.> Cons))

The "Define" construct is there merely for generating better 
error messages. We can see that unziplist is defined as the 
inverse of ziplist, while ziplist is simply the ordinary zipping 
function written in point-free style. Try

   X> ev unziplist "<1,4>:<2,5>:<3,6>:[]"
   Right <1:2:3:[],4:5:6:[]>

The list of pairs "<1,4>:<2,5>:<3,6>:[]" is split into a pair of 
lists "<1:2:3:[],4:5:6:[]>". We write pairs in angle brackets, 
and write lists using cons (:) and nil ([]).

Running the output through the inverse of unziplist (that is, 
ziplist) gives us the original input:

   X> ev ziplist "<1:2:3:[],4:5:6:[]>"
   Right (<1,4>:<2,5>:<3,6>:[])

What if we delete an element in the second list?

   X> ev ziplist "<1:2:3:[],4:\(5:6:[])>"
   Right (<1,4>:\(<2,5>:<3,6>:[]))

The slash (\) denotes deletion. Here the element 5 is deleted (it 
ought to be a single slash, however, in a string the slash is 
double-escaped). In the output, the pair <2,5> is deleted, as we 
expect. Insertion, on the other hand ,is denoted by (^).

   X> ev ziplist "<1:2:3:[],4:^(7:5:6:[])>"
   Right (<1,4>:^(<_|_,7>:<2,5>:<3,6>:[]))

The function "snoc", defined in InvPrelude, appends an element 
to the end of a list. Its inverse extracts the last element.

   X> ev (Inv snoc) "1:2:3:4:5:[]"
   Right <5,1:2:3:4:[]>

What happens if we delete the last element before applying Inv snoc? We get

   X> ev (Inv snoc) "1:2:3:4:\(5:[])"
   Right <-5,1:2:3:4:[]>
 
Here <-_,_> is the "negative pair" in the paper. The function "rev" is 
defined as rev = fold snoc Nil and relies on snoc to work correctly.

   X> ev (Inv rev) "1:2:3:\(4:5:[])"
   Right (5:\(4:3:2:1:[]))


2. The bidirectional Language X
===============================

Documentation to be completed.


3. XEditor
==========

Documentation to be completed.


4. HaXML Embedding
==================

To load the XML Embedding, do

   hugs -98 InXmlTest.lhs
   ghci InXmlTest.lhs

In InXmlTest.hs, where some testing examples are, we have defined:

  fn = mkElem "m" [tag "a" `o'` children, children]
  t5 = "{'r',{'b',[]}:{'a',[]}:[]}"

Let us try applying the transformation fn to t5

  *InXmlTest> ev fn t5
  Right <{'r',{'b',[]}:{'a',[]}:[]},
         {'m',{'a',[]}:{'b',[]}:{'a',[]}:[]}:[]>

The result is a pair, where the first component is a copy of
the input while the second copy is the view (the output is
idented for this README file for readability only. 
In the interpreter the output is currently a single line
of text. So shall the input be a long string without
line break. We will work on a pretty printer and a better
parser.) PUTting them back yields the same tree:

  *InXmlTest> ev (Inv fn) "<{'r',{'b',[]}:{'a',[]}:[]},
                            {'m',{'a',[]}:{'b',[]}:{'a',[]}:[]}:[]>"
   Right {'r',{'b',[]}:{'a',[]}:[]}

Now assume that we delete {'b',[]} in the view:


  *InXmlTest> ev (Inv fn) "<{'r',{'b',[]}:{'a',[]}:[]},
                            {'m',{'a',[]}:\\({'b',[]}:{'a',[]}:[])}:[]>"

  Right {'r',\({'b',[]}:{'a',[]}:[])}

The corresponding subtree in the original tree is deleted.

Let us try some insertion:

  *InXmlTest> ev (Inv fn) "<{'r',{'b',[]}:{'a',[]}:[]},
                            {'m',{'a',[]}:^({'b',1:[]}:{'b',[]}:{'a',[]}:[])}:[]>"
  Right {'r',^({'b',1:[]}:{'b',[]}:{'a',[]}:[])}

  *InXmlTest> ev (Inv fn) "<{'r',{'b',[]}:{'a',[]}:[]},
                            {'m',^({'a',1:[]}:{'a',[]}:{'b',[]}:{'a',[]}:[])}:[]>"
  Right {'r',{'b',[]}:^({'a',1:[]}:{'a',[]}:[])}


For a bigger example, we have defined

  addrbook2' = "{'a',{'p',{'n','ZH':[]}:
                          {'e','hu@mist':[]}:[]}:
                     {'p',{'n','KE':[]}:
                          {'e','emoto@ipl':[]}:[]}:
                     {'p',{'n','SCM':[]}:
                          {'e','scm@mist':[]}:[]}:[]}"

It is essentially the same address book example in the
paper, with all the tag names shortened and number of
fields removed to be more readable in the interpreter.
The forward run goes:

  InXmlTest> ev mkView addrbook2'
  Right <{'a',{'p',{'n','ZH':[]}:
                   {'e','hu@mist':[]}:[]}:
              {'p',{'n','KE':[]}:
                   {'e','emoto@ipl':[]}:[]}:
              {'p',{'n','SCM':[]}:
                   {'e','scm@mist':[]}:[]}:[],
         {'html',{'ul',{'li','ZH':[]}:
                       {'li','KE':[]}:
                       {'li','SCM':[]}:[]}:
                 {'table',{'tr',{'td','ZH':[]}:
                                {'td','hu@mist':[]}:[]}:
                          {'tr',{'td','KE':[]}:
                                {'td','emoto@ipl':[]}:[]}:
                          {'tr',{'td','SCM':[]}:
                                {'td','scm@mist':[]}:[]}:[]}:[]}:[]>

Now let us add a new row to the table.

  InXmlTest> ev (Inv mkView) 
     "<{'a',{'p',{'n','ZH':[]}:
                 {'e','hu@mist':[]}:[]}:
            {'p',{'n','KE':[]}:
                 {'e','emoto@ipl':[]}:[]}:
            {'p',{'n','SCM':[]}:
                 {'e','scm@mist':[]}:[]}:[]},
       {'html',{'ul',{'li','ZH':[]}:
                     {'li','KE':[]}:
                     {'li','SCM':[]}:[]}:
               {'table',{'tr',{'td','ZH':[]}:
                              {'td','hu@mist':[]}:[]}:
                      ^({'tr',{'td','KN':[]}:
                              {'td','ksk@ipl':[]}:[]}:
                        {'tr',{'td','KE':[]}:
                              {'td','emoto@ipl':[]}:[]}:
                        {'tr',{'td','SCM':[]}:
                              {'td','scm@mist':[]}:[]}:[])}:[]}:[]>"
  Right {'a',{'p',{'n','ZH':[]}:
                  {'e','hu@mist':[]}:[]}:
           ^({'p',{'n','KN':[]}:
                  {'e','ksk@ipl':[]}:[]}:
             {'p',{'n','KE':[]}:
                  {'e','emoto@ipl':[]}:[]}:
             {'p',{'n','SCM':[]}:
                  {'e','scm@mist':[]}:[]}:[])}

The new person is added back to the addressbook. We can also
try adding to the index:

  InXmlTest> ev (Inv mkView) 
     "<{'a',{'p',{'n','ZH':[]}:
                 {'e','hu@mist':[]}:[]}:
            {'p',{'n','KE':[]}:
                 {'e','emoto@ipl':[]}:[]}:
            {'p',{'n','SCM':[]}:
                 {'e','scm@mist':[]}:[]}:[]},
       {'html',{'ul',{'li','ZH':[]}:
                   ^({'li', 'KN':[]}:
                     {'li','KE':[]}:
                     {'li','SCM':[]}:[])}:
               {'table',{'tr',{'td','ZH':[]}:
                              {'td','hu@mist':[]}:[]}:
                        {'tr',{'td','KE':[]}:
                              {'td','emoto@ipl':[]}:[]}:
                        {'tr',{'td','SCM':[]}:
                              {'td','scm@mist':[]}:[]}:[]}:[]}:[]>"
  Right {'a',{'p',{'n','ZH':[]}:
                  {'e','hu@mist':[]}:[]}:
           ^({'p',{'n','KN':[]}:
                   _|_:[]}:
             {'p',{'n','KE':[]}:
                  {'e','emoto@ipl':[]}:[]}:
             {'p',{'n','SCM':[]}:
                  {'e','scm@mist':[]}:[]}:[])}

The unknown field is denoted by _|_.

References
===========

  1. S-C. Mu, Z. Hu and M. Takeichi, An injective language for 
     reversible computation. In Mathematics of Programming 
     Construction 2004, LNCS 3125, pp. 289-313, July 2004.

  2. S-C. Mu, Z. Hu and M. Takeichi, An algebraic approach 
     to bidirectional updating. In The Second Asian Symposium 
     on Programming Language and Systems, pp. 2-18. November 
     2004.
